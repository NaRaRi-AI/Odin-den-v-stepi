import { useEffect, useState } from "react";
import { Feather, Flame, Landmark, RotateCcw, Share2, Wind } from "lucide-react";
import {
  START_ID,
  endingMemory,
  endings,
  scenes,
  type Ending,
  type Scene,
  type Sky,
} from "@/quest/story";
import { depth } from "@/quest/depth";

const KEY = "den-v-stepi-v1";

type Save = {
  phase: "intro" | "play" | "ending";
  sceneId: string;
  luck: number;
  wisdom: number;
  flags: string[];
  trail: string[];
  endingId: string | null;
  echo: string;
  deltaLuck: number;
  deltaWisdom: number;
};

const initial: Save = {
  phase: "intro",
  sceneId: START_ID,
  luck: 0,
  wisdom: 0,
  flags: [],
  trail: [],
  endingId: null,
  echo: "",
  deltaLuck: 0,
  deltaWisdom: 0,
};

const endingIcon = {
  hearth: Flame,
  herald: Feather,
  stone: Landmark,
  winds: Wind,
} as const;

export function Quest() {
  const [save, setSave] = useState<Save>(initial);
  const [ready, setReady] = useState(false);
  const [copied, setCopied] = useState(false);
  const [confirmLeave, setConfirmLeave] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Save;
        const sceneOk = parsed.sceneId in scenes;
        const endingOk = parsed.endingId == null || parsed.endingId in endings;
        if (parsed?.phase && sceneOk && endingOk) setSave(parsed);
      }
    } catch {
      /* keep a fresh day */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEY, JSON.stringify(save));
  }, [save, ready]);

  function begin() {
    setCopied(false);
    setConfirmLeave(false);
    setSave({
      ...initial,
      phase: "play",
      sceneId: START_ID,
      trail: [scenes[START_ID].title],
    });
  }

  function restart() {
    localStorage.removeItem(KEY);
    setCopied(false);
    setConfirmLeave(false);
    setSave(initial);
  }

  function choose(scene: Scene, index: number) {
    const choice = scene.choices[index];
    const flags = Array.from(new Set([...save.flags, ...choice.flags]));
    const luck = save.luck + choice.luck;
    const wisdom = save.wisdom + choice.wisdom;
    if (choice.next.startsWith("end:")) {
      setSave({
        ...save,
        phase: "ending",
        luck,
        wisdom,
        flags,
        endingId: choice.next.slice(4),
        echo: choice.echo,
        deltaLuck: choice.luck,
        deltaWisdom: choice.wisdom,
      });
      return;
    }
    const next = scenes[choice.next];
    setSave({
      ...save,
      phase: "play",
      sceneId: next.id,
      luck,
      wisdom,
      flags,
      trail: [...save.trail, next.title],
      echo: choice.echo,
      deltaLuck: choice.luck,
      deltaWisdom: choice.wisdom,
    });
  }

  async function share(title: string) {
    const text = `Я прошёл день в степи и открыл финал «${title}». Попробуй и ты.`;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
  }

  const sky: Sky =
    save.phase === "intro"
      ? "predawn"
      : save.phase === "ending"
        ? "night"
        : (scenes[save.sceneId]?.sky ?? "night");

  const scene = scenes[save.sceneId] ?? scenes[START_ID];
  const ending = save.endingId ? endings[save.endingId] : undefined;

  return (
    <main className="relative min-h-dvh overflow-x-hidden bg-night text-parchment">
      <SteppeSky sky={sky} />
      <div className="grain" />
      <div className="scrim" />
      <div className="safe-pad relative mx-auto flex min-h-dvh w-full max-w-xl flex-col px-5 py-6 sm:max-w-2xl sm:px-8 sm:py-12">
        <header className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs tracking-widest text-gold uppercase">Один день в степи</p>
            {save.phase === "play" ? (
              <p className="mt-1 text-sm text-parchment/70">
                {scene.hour} · {scene.branch}
              </p>
            ) : (
              <p className="mt-1 text-sm text-parchment/70">Урочище Сухой Брод</p>
            )}
          </div>
          <div className="flex w-36 shrink-0 flex-col gap-2">
            <Meter label="Удача" value={save.luck} tone="ember" />
            <Meter label="Мудрость" value={save.wisdom} tone="gold" />
          </div>
        </header>

        {save.phase === "intro" ? (
          <Intro onStart={begin} />
        ) : save.phase === "ending" && ending ? (
          <EndingView
            ending={ending}
            echo={save.echo}
            memory={endingMemory(ending.id, save.flags)}
            luck={save.luck}
            wisdom={save.wisdom}
            copied={copied}
            onRestart={restart}
            onShare={() => share(ending.title)}
          />
        ) : (
          <SceneView
            key={scene.id}
            scene={scene}
            echo={save.echo}
            deltaLuck={save.deltaLuck}
            deltaWisdom={save.deltaWisdom}
            flags={save.flags}
            trail={save.trail}
            confirmLeave={confirmLeave}
            onChoose={(index) => choose(scene, index)}
            onAskLeave={() => setConfirmLeave(true)}
            onStay={() => setConfirmLeave(false)}
            onRestart={restart}
          />
        )}
      </div>
    </main>
  );
}

function Meter({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "gold" | "ember";
}) {
  const width = Math.max(8, Math.min(100, 8 + value * 7));
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2 text-xs tracking-wide">
        <span className="text-gold/80">{label}</span>
        <span className="tabular-nums text-parchment">{value}</span>
      </div>
      <div className="mt-1 h-px w-full bg-gold/25">
        <div
          className={tone === "gold" ? "h-px bg-gold" : "h-px bg-ember"}
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}

function Intro({ onStart }: { onStart: () => void }) {
  return (
    <article className="mt-6 flex flex-1 flex-col sm:mt-16">
      <p className="rise text-sm tracking-widest text-gold uppercase">Исторический миф</p>
      <h1 className="rise d1 mt-3 font-display text-4xl leading-none text-parchment sm:text-7xl">
        Один день в степи
      </h1>
      <p className="rise d2 mt-3 max-w-md font-display text-xl leading-snug text-gold italic sm:mt-4 sm:text-3xl">
        Между курганом и солью есть час, когда тропа ещё не решила, пустить ли тебя.
      </p>
      <div className="rise d3 mt-5 max-w-prose space-y-3 text-base leading-relaxed text-parchment/90 sm:mt-8 sm:space-y-4 sm:text-lg">
        <p>
          Караван ушёл вниз ещё вчера. Ты остался у остывающего костра в урочище, которое путники зовут
          Сухим Бродом: слева старые камни, справа чёрная вода, соль и тростник. Впереди не карта с крестом.
          Впереди день.
        </p>
        <p>
          Путь ветвится. Второй проход не повторит первый: гряда стражей, чёрная переправа или поворот
          посреди полдня. Если читать не спеша, это около получаса.
        </p>
      </div>
      <div className="rise d4 sticky bottom-0 mt-6 bg-linear-to-t from-night via-night to-transparent pt-4 pb-2">
        <button type="button" className="choice min-h-14 w-full rounded-full bg-panel px-8 text-lg text-parchment sm:w-auto" onClick={onStart}>
          Начать путь
        </button>
      </div>
    </article>
  );
}

function SceneView({
  scene,
  echo,
  deltaLuck,
  deltaWisdom,
  flags,
  trail,
  confirmLeave,
  onChoose,
  onAskLeave,
  onStay,
  onRestart,
}: {
  scene: Scene;
  echo: string;
  deltaLuck: number;
  deltaWisdom: number;
  flags: string[];
  trail: string[];
  confirmLeave: boolean;
  onChoose: (index: number) => void;
  onAskLeave: () => void;
  onStay: () => void;
  onRestart: () => void;
}) {
  const memories = (scene.memories ?? []).filter((item) => flags.includes(item.flag));
  return (
    <article className="mt-8 flex flex-1 flex-col">
      <h2 className="rise font-display text-4xl leading-tight text-parchment sm:text-5xl">{scene.title}</h2>
      {echo ? (
        <div className="rise d1 mt-5 border-l border-gold/50 pl-4">
          <p className="font-display text-lg leading-relaxed text-gold italic">{echo}</p>
          <p className="mt-2 text-xs tracking-wide text-parchment/70">
            {deltaWisdom > 0 ? `Мудрость +${deltaWisdom}` : null}
            {deltaWisdom > 0 && deltaLuck > 0 ? " · " : null}
            {deltaLuck > 0 ? `Удача +${deltaLuck}` : null}
          </p>
        </div>
      ) : null}
      <div className="mt-6 space-y-4 text-lg leading-relaxed text-parchment/92">
        {scene.paragraphs.map((paragraph, index) => (
          <p key={paragraph.slice(0, 24)} className={index === 0 ? "rise d2" : index === 1 ? "rise d3" : "rise d4"}>
            {paragraph}
          </p>
        ))}
        {depth[scene.id] ? <p className="rise d5">{depth[scene.id]}</p> : null}
        {memories.map((item) => (
          <p key={item.flag} className="text-base text-gold/90 italic">
            {item.text}
          </p>
        ))}
      </div>
      {trail.length > 1 ? (
        <p className="mt-6 text-sm leading-relaxed text-parchment/55">{trail.join(" · ")}</p>
      ) : null}
      <div className="mt-8 flex flex-col gap-3">
        {scene.choices.map((choice, index) => (
          <button
            key={choice.id}
            type="button"
            className="choice rounded-2xl bg-panel px-4 py-4 text-left"
            onClick={() => onChoose(index)}
          >
            <span className="block font-display text-xl leading-snug text-parchment">{choice.title}</span>
            <span className="mt-1 block text-sm leading-relaxed text-parchment/65">{choice.hint}</span>
          </button>
        ))}
      </div>
      <div className="mt-8 pb-4">
        {confirmLeave ? (
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <span className="text-parchment/70">Забыть этот день?</span>
            <button type="button" className="text-gold underline-offset-4 hover:underline" onClick={onRestart}>
              Да, с начала
            </button>
            <button type="button" className="text-parchment/80 underline-offset-4 hover:underline" onClick={onStay}>
              Остаться
            </button>
          </div>
        ) : (
          <button type="button" className="text-sm text-parchment/45 underline-offset-4 hover:text-parchment/80 hover:underline" onClick={onAskLeave}>
            Бросить день
          </button>
        )}
      </div>
    </article>
  );
}

function EndingView({
  ending,
  echo,
  memory,
  luck,
  wisdom,
  copied,
  onRestart,
  onShare,
}: {
  ending: Ending;
  echo: string;
  memory: string | null;
  luck: number;
  wisdom: number;
  copied: boolean;
  onRestart: () => void;
  onShare: () => void;
}) {
  const Icon = endingIcon[ending.id as keyof typeof endingIcon] ?? Wind;
  return (
    <article className="mt-8 flex flex-1 flex-col">
      <div className="rise flex size-14 items-center justify-center rounded-full border border-gold/40 text-gold">
        <Icon aria-hidden="true" className="size-7" strokeWidth={1.5} />
      </div>
      <p className="rise d1 mt-5 text-xs tracking-widest text-gold uppercase">{ending.kicker}</p>
      <h2 className="rise d1 mt-2 font-display text-5xl leading-none text-parchment sm:text-6xl">{ending.title}</h2>
      <p className="rise d2 mt-5 font-display text-2xl leading-snug text-gold italic">{ending.quote}</p>
      {echo ? <p className="rise d3 mt-6 text-base leading-relaxed text-parchment/75">{echo}</p> : null}
      <div className="mt-6 space-y-4 text-lg leading-relaxed text-parchment/92">
        {ending.paragraphs.map((paragraph) => (
          <p key={paragraph.slice(0, 24)}>{paragraph}</p>
        ))}
        {memory ? <p className="text-gold/90 italic">{memory}</p> : null}
      </div>
      <p className="mt-6 text-sm tracking-wide text-parchment/60">
        Удача {luck} · Мудрость {wisdom}
      </p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <button type="button" className="choice inline-flex min-h-14 items-center justify-center gap-2 rounded-full bg-panel px-6 text-base text-parchment" onClick={onRestart}>
          <RotateCcw className="size-4" aria-hidden="true" />
          Пройти заново
        </button>
        <button type="button" className="choice inline-flex min-h-14 items-center justify-center gap-2 rounded-full bg-panel px-6 text-base text-parchment" onClick={onShare}>
          <Share2 className="size-4" aria-hidden="true" />
          {copied ? "Скопировано" : "Поделиться результатом"}
        </button>
      </div>
    </article>
  );
}

function SteppeSky({ sky }: { sky: Sky }) {
  const night = sky === "night" || sky === "predawn";
  const storm = sky === "storm";
  return (
    <div className="pointer-events-none absolute inset-0" aria-hidden="true">
      <svg className="h-full w-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="steppe-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={storm ? "var(--color-panel)" : "var(--color-panel)"} />
            <stop offset="48%" stopColor="var(--color-night)" />
            <stop offset="100%" stopColor="var(--color-night)" />
          </linearGradient>
          <radialGradient id="steppe-fire" cx="50%" cy="92%" r="55%">
            <stop offset="0%" stopColor="var(--color-ember)" stopOpacity={storm ? "0.2" : "0.55"} />
            <stop offset="70%" stopColor="var(--color-ember)" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="steppe-moon" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="var(--color-parchment)" />
            <stop offset="70%" stopColor="var(--color-gold)" />
          </radialGradient>
        </defs>
        <rect width="1200" height="800" fill="url(#steppe-sky)" />
        {night ? (
          <g opacity="0.9">
            <circle cx="860" cy="128" r="36" fill="url(#steppe-moon)" />
            <circle cx="876" cy="116" r="32" fill="var(--color-night)" />
          </g>
        ) : null}
        {sky === "day" || sky === "morning" ? (
          <circle cx="180" cy="150" r="50" fill="var(--color-gold)" opacity={sky === "morning" ? "0.18" : "0.28"} />
        ) : null}
        <path d="M0 470 C 180 430, 320 500, 520 460 C 760 410, 900 490, 1200 440 L 1200 800 L 0 800 Z" fill="var(--color-panel)" opacity="0.85" />
        <path d="M0 540 C 200 500, 380 580, 640 530 C 860 490, 1000 560, 1200 520 L 1200 800 L 0 800 Z" fill="var(--color-night)" />
        <g stroke="var(--color-gold)" strokeWidth="1.2" opacity="0.45" fill="none">
          {grass.map((blade) => (
            <path key={blade} d={blade} />
          ))}
        </g>
        {storm ? (
          <path
            className="bolt"
            d="M740 80 L700 190 L760 190 L690 320"
            stroke="var(--color-parchment)"
            strokeWidth="2"
            fill="none"
            opacity="0.75"
          />
        ) : null}
        <rect width="1200" height="800" fill="url(#steppe-fire)" />
      </svg>
      <span className="mote mote-a" />
      <span className="mote mote-b" />
      <span className="mote mote-c" />
    </div>
  );
}

const grass = [
  "M80 560 q 6 -28 2 -2",
  "M140 575 q 8 -36 1 -2",
  "M230 568 q 5 -24 2 -1",
  "M310 590 q 9 -40 0 -2",
  "M420 572 q 6 -30 2 -2",
  "M510 600 q 8 -34 1 -1",
  "M640 580 q 7 -38 2 -2",
  "M760 610 q 6 -28 1 -1",
  "M880 575 q 9 -42 2 -2",
  "M990 598 q 5 -26 1 -1",
  "M1100 568 q 8 -36 2 -2",
];
