import React from "react";
import { createRoot } from "react-dom/client";
import { Quest } from "./quest/Quest";
import "./styles.css";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <Quest />
  </React.StrictMode>,
);
