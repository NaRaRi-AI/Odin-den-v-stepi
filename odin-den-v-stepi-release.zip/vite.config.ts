import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const repo = process.env.GITHUB_REPOSITORY?.split("/")[1] ?? "Odin-den-v-stepi";
const base = process.env.GITHUB_ACTIONS === "true" ? `/${repo}/` : "/";

export default defineConfig({
  base,
  resolve: { alias: { "@": resolve(here, "src") } },
  plugins: [react(), tailwindcss()],
  build: { outDir: "dist", emptyOutDir: true },
});
